package com.example.admin.kitchennearby;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Signin extends Activity {
    EditText email,password;
    TextView signin,forgotpassword,register;
    private static String KEY_SUCCESS = "success";
    String response = null;
    TextView  txt_Error;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        email = (EditText)findViewById(R.id.etEmail);
        password = (EditText)findViewById(R.id.etPassword);
        signin = (TextView) findViewById(R.id.tvLogin);
        forgotpassword = (TextView)findViewById(R.id.tvForgotPassword);
        register = (TextView)findViewById(R.id.tvRegister);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(Signin.this,Signup.class);
                startActivity(in);
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (  ( !email.getText().toString().equals("")) && ( !password.getText().toString().equals("")) )
                {

                }
                else if ( ( !email.getText().toString().equals("")) )
                {
                    Toast.makeText(getApplicationContext(),
                            "Password field empty", Toast.LENGTH_SHORT).show();
                }
                else if ( ( !password.getText().toString().equals("")) )
                {
                    Toast.makeText(getApplicationContext(),
                            "Email field empty", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),
                            "Email and Password field are empty", Toast.LENGTH_SHORT).show();
                }

                String semail = email.getText().toString();
                String spassword = password.getText().toString();

                validateUserTask task = new validateUserTask();
                task.execute(semail, spassword);

                Intent in = new Intent(Signin.this,Chooseyouraccount.class);
                startActivity(in);
            }
        });

    }

    public void onBackPressed() {
        finish();
    }

    private class validateUserTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub
            ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
            postParameters.add(new BasicNameValuePair("email", params[0] ));
            postParameters.add(new BasicNameValuePair("password", params[1] ));
            String res = null;
            try {
                response = CustomHttpClient.executeHttpPost("http://kitchen.appraytechnologies.in/login", postParameters);
                res=response.toString();
                res= res.replaceAll("\\s+","");
            }
            catch (Exception e) {
                txt_Error.setText(e.toString());
            }
            return res;
        }//close doInBackground

        @Override
        protected void onPostExecute(String result) {
            if(result.equals("1")){
                //navigate to Main Menu
                Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Signin.this, Chooseyouraccount.class);
                startActivity(i);
            }
            else{

                Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
            }
        }//close onPostExecute
    }// close validateUserTask
}//close LoginActivity